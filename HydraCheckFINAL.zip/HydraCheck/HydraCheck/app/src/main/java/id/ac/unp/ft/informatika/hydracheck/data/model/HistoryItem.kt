package id.ac.unp.ft.informatika.hydracheck.data.model

data class HistoryItem(
    var id: String = "",
    var score: Int = 0,
    var status: String = "",
    var description: String = "",
    var timestamp: Long = 0L
)
