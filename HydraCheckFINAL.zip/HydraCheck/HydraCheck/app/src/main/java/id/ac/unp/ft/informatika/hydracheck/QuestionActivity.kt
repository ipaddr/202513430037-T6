package id.ac.unp.ft.informatika.hydracheck

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

data class Question(
    val questionText: String,
    val description: String,
    val options: List<String>,
    val scores: List<Int>
)

class QuestionActivity : AppCompatActivity() {

    private lateinit var progressArc: ArcProgressView

    private lateinit var btnClose: ImageView
    private lateinit var btnPrev: Button
    private lateinit var btnNext: Button

    private lateinit var tvProgress: TextView
    private lateinit var tvQuestion: TextView
    private lateinit var tvDescription: TextView

    private lateinit var optionLayouts: List<LinearLayout>
    private lateinit var optionTexts: List<TextView>

    private val questions = listOf(
        Question(
            "Seberapa sering Anda merasa haus?",
            "Rasa haus berlebihan dapat menandakan dehidrasi.",
            listOf("Normal", "Kadang haus", "Sering haus", "Sangat sering haus"),
            listOf(0, 1, 2, 3)
        ),
        Question(
            "Bagaimana warna urin Anda?",
            "Semakin pekat warnanya, semakin mungkin Anda kekurangan cairan.",
            listOf("Jernih", "Kuning muda", "Kuning pekat", "Oranye"),
            listOf(0, 1, 2, 3)
        ),
        Question(
            "Seberapa sering Anda buang air kecil?",
            "Frekuensi menurun bisa menjadi tanda dehidrasi.",
            listOf("6–8 kali", "4–5 kali", "2–3 kali", "< 2 kali"),
            listOf(0, 1, 2, 3)
        ),
        Question(
            "Bagaimana kondisi mulut Anda?",
            "Mulut kering sering muncul saat tubuh kekurangan cairan.",
            listOf("Normal", "Sedikit kering", "Kering", "Sangat kering"),
            listOf(0, 1, 2, 3)
        ),
        Question(
            "Apakah Anda merasa pusing?",
            "Pusing dapat muncul akibat dehidrasi.",
            listOf("Tidak pernah", "Kadang", "Sering", "Sangat sering"),
            listOf(0, 1, 2, 3)
        ),
        Question(
            "Bagaimana tingkat energi Anda?",
            "Dehidrasi dapat menyebabkan tubuh lemas.",
            listOf("Energi baik", "Sedikit lelah", "Lelah sering", "Sangat lelah"),
            listOf(0, 1, 2, 3)
        ),
        Question(
            "Apakah Anda mengalami kram otot?",
            "Kurang cairan dapat memicu kram otot.",
            listOf("Tidak pernah", "Jarang", "Kadang", "Sering"),
            listOf(0, 1, 2, 3)
        ),
        Question(
            "Bagaimana kondisi mata Anda?",
            "Mata cekung/kering adalah tanda dehidrasi.",
            listOf("Normal", "Sedikit kering", "Kering", "Sangat kering"),
            listOf(0, 1, 2, 3)
        )
    )

    private var currentIndex = 0
    private var totalScore = 0
    private val answers = IntArray(questions.size) { -1 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_question)

        progressArc = findViewById(R.id.progressArc)

        btnClose = findViewById(R.id.btnClose)
        btnPrev = findViewById(R.id.btnPrev)
        btnNext = findViewById(R.id.btnNext)

        tvProgress = findViewById(R.id.tvProgress)
        tvQuestion = findViewById(R.id.tvQuestion)
        tvDescription = findViewById(R.id.tvDescription)

        optionLayouts = listOf(
            findViewById(R.id.option1),
            findViewById(R.id.option2),
            findViewById(R.id.option3),
            findViewById(R.id.option4)
        )

        optionTexts = listOf(
            findViewById(R.id.optionText1),
            findViewById(R.id.optionText2),
            findViewById(R.id.optionText3),
            findViewById(R.id.optionText4)
        )

        optionLayouts.forEachIndexed { index, layout ->
            layout.setOnClickListener { selectOption(index) }
        }

        btnNext.setOnClickListener { nextQuestion() }
        btnPrev.setOnClickListener { previousQuestion() }
        btnClose.setOnClickListener { showExitDialog() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                showExitDialog()
            }
        })

        loadQuestion()
    }

    private fun loadQuestion() {
        val q = questions[currentIndex]

        tvProgress.text = "Pertanyaan ${currentIndex + 1} dari ${questions.size}"
        tvQuestion.text = q.questionText
        tvDescription.text = q.description

        optionTexts.forEachIndexed { i, tv ->
            tv.text = q.options[i]
        }

        restoreSelection()
        btnPrev.isEnabled = currentIndex > 0

        // Update progressArc → mulus
        val progress = (currentIndex + 1).toFloat() / questions.size
        progressArc.setProgress(progress)
    }

    private fun restoreSelection() {
        val prev = answers[currentIndex]
        optionLayouts.forEach { it.setBackgroundResource(R.drawable.answer_option_default) }

        if (prev != -1) {
            optionLayouts[prev].setBackgroundResource(R.drawable.answer_option_selected)
        }
    }

    private fun selectOption(index: Int) {
        answers[currentIndex] = index

        optionLayouts.forEach { it.setBackgroundResource(R.drawable.answer_option_default) }
        optionLayouts[index].setBackgroundResource(R.drawable.answer_option_selected)
    }

    private fun nextQuestion() {
        if (answers[currentIndex] == -1) {
            Toast.makeText(this, "Pilih jawaban terlebih dahulu", Toast.LENGTH_SHORT).show()
            return
        }

        if (currentIndex == questions.size - 1) {
            val status = calculateScore()

            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("TOTAL_SCORE", totalScore)
            intent.putExtra("STATUS", status)
            intent.putExtra("ANSWERS", answers.toList().toIntArray())
            startActivity(intent)
            finish()
            return
        }


        currentIndex++
        loadQuestion()
    }

    private fun previousQuestion() {
        if (currentIndex > 0) {
            currentIndex--
            loadQuestion()
        }
    }

    private fun calculateScore(): String {
        totalScore = answers.indices.sumOf { i ->
            questions[i].scores[answers[i]]
        }
        return getHydrationStatus(totalScore)
    }


    private fun showExitDialog() {
        AlertDialog.Builder(this)
            .setTitle("Keluar Asesmen?")
            .setMessage("Apakah Anda yakin ingin keluar? Jawaban Anda akan hilang.")
            .setPositiveButton("Ya") { _: DialogInterface, _: Int ->
                finish()
            }
            .setNegativeButton("Tidak", null)
            .show()
    }

    private fun getHydrationStatus(totalScore: Int): String {
        return when (totalScore) {
            in 0..6 -> "Hidrasi Baik"
            in 7..12 -> "Dehidrasi Ringan"
            in 13..18 -> "Dehidrasi Sedang"
            else -> "Dehidrasi Berat" // 19–24
        }
    }



}
