package id.ac.unp.ft.informatika.hydracheck.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import id.ac.unp.ft.informatika.hydracheck.data.repository.UserRepository
import id.ac.unp.ft.informatika.hydracheck.data.local.UserEntity
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class UserViewModel(private val repo: UserRepository) : ViewModel() {

    private val _user = MutableStateFlow<UserEntity?>(null)
    val user: StateFlow<UserEntity?> = _user

    // -------------------------------------------------
    // LOGIN EMAIL
    // -------------------------------------------------
    fun loginWithEmail(email: String, password: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            try {
                val result = repo.loginWithEmail(email, password)
                val uid = result.user?.uid ?: return@launch onResult(false, "UID null")

                val name = result.user?.displayName ?: "User"
                repo.saveUser(uid, name, email)

                _user.value = repo.getLoggedInUser(uid)
                onResult(true, null)

            } catch (e: Exception) {
                onResult(false, e.message)
            }
        }
    }

    // -------------------------------------------------
    // LOGIN GOOGLE
    // -------------------------------------------------
    fun loginWithGoogle(idToken: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            try {
                val result = repo.loginWithGoogle(idToken)
                val user = result.user ?: return@launch onResult(false, "User null")

                val uid = user.uid
                val name = user.displayName ?: "User"
                val email = user.email ?: "-"

                repo.saveUser(uid, name, email)

                _user.value = repo.getLoggedInUser(uid)
                onResult(true, null)

            } catch (e: Exception) {
                onResult(false, e.message)
            }
        }
    }

    // -------------------------------------------------
    // GET LOGGED IN USER
    // -------------------------------------------------
    fun loadUser(uid: String) {
        viewModelScope.launch {
            _user.value = repo.getLoggedInUser(uid)
        }
    }

    // -------------------------------------------------
    // LOGOUT
    // -------------------------------------------------
    fun logout() = repo.logout()
}
