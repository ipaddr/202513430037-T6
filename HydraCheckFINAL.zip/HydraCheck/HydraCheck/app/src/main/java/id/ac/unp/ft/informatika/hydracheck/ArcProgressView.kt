package id.ac.unp.ft.informatika.hydracheck

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.animation.ValueAnimator
import androidx.core.content.ContextCompat

class ArcProgressView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private var progress = 0f          // value 0.0 – 1.0
    private var animatedProgress = 0f  // smooth version

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E5EFFF")
        strokeWidth = 24f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3A8DFF")
        strokeWidth = 24f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val oval = RectF()

    fun setProgress(value: Float) {
        progress = value.coerceIn(0f, 1f)
        animateProgress()
    }

    private fun animateProgress() {
        val animator = ValueAnimator.ofFloat(animatedProgress, progress)
        animator.duration = 400
        animator.addUpdateListener {
            animatedProgress = it.animatedValue as Float
            invalidate()
        }
        animator.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val padding = 20f
        oval.set(
            padding,
            padding,
            width - padding,
            height * 2 - padding
        )

        // Background arc (full 180°)
        canvas.drawArc(oval, 180f, 180f, false, bgPaint)

        // Progress arc
        canvas.drawArc(oval, 180f, 180f * animatedProgress, false, progressPaint)
    }
}
