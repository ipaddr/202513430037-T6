package id.ac.unp.ft.informatika.hydracheck.data.model

data class QuestionFirestore(
    val text: String = "",
    val description: String = "",
    val options: List<String> = emptyList(),
    val scores: List<Int> = emptyList()
)
