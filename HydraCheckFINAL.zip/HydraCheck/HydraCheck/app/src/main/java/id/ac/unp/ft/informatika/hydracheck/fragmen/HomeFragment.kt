package id.ac.unp.ft.informatika.hydracheck.fragmen

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import id.ac.unp.ft.informatika.hydracheck.AccountActivity
import id.ac.unp.ft.informatika.hydracheck.MainActivity
import id.ac.unp.ft.informatika.hydracheck.QuestionActivity
import id.ac.unp.ft.informatika.hydracheck.R
import android.util.Base64
import android.graphics.BitmapFactory

class HomeFragment : Fragment(R.layout.fragment_home) {

    private lateinit var tvName: TextView
    private lateinit var tvEmail: TextView
    private lateinit var imgUser: ImageView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // === Bind view ===
        tvName = view.findViewById(R.id.tvUserName)
        tvEmail = view.findViewById(R.id.tvUserEmail)
        imgUser = view.findViewById(R.id.imgUser)

        val btnStartTest = view.findViewById<Button>(R.id.btnStartTest)
        val btnSeeHistory = view.findViewById<Button>(R.id.btnSeeHistory)
        val tvEmpty = view.findViewById<TextView>(R.id.tvEmptyProfile)

        // === Ambil UID ===
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return

        FirebaseFirestore.getInstance()
            .collection("users")
            .document(uid)
            .get()
            .addOnSuccessListener { document ->

                if (!document.exists()) {
                    tvName.text = "Pengguna"
                    tvEmail.text = ""
                    tvEmpty.visibility = View.VISIBLE
                    return@addOnSuccessListener
                }

                tvName.text = document.getString("name") ?: "Pengguna"
                tvEmail.text = document.getString("email") ?: ""

                val photoBase64 = document.getString("photoBase64")
                if (!photoBase64.isNullOrEmpty()) {
                    val bytes = Base64.decode(photoBase64, Base64.DEFAULT)
                    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    imgUser.setImageBitmap(bitmap)
                    tvEmpty.visibility = View.GONE
                } else {
                    tvEmpty.visibility = View.VISIBLE
                }
            }

        // === Ambil skor terakhir ===
        FirebaseFirestore.getInstance()
            .collection("users")
            .document(uid)
            .collection("history")
            .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(1)
            .get()
            .addOnSuccessListener { result ->
                if (!result.isEmpty) {
                    val lastDoc = result.documents[0]
                    val lastScore = lastDoc.getLong("score") ?: 0

                    view.findViewById<TextView>(R.id.tvLastScore)
                        .text = "Skor Terakhir: $lastScore"
                }
            }


        // === Action ===
        btnStartTest.setOnClickListener {
            startActivity(Intent(requireContext(), QuestionActivity::class.java))
        }

        btnSeeHistory.setOnClickListener {
            (requireActivity() as MainActivity).openHistoryFromHome()
        }

        imgUser.setOnClickListener {
            startActivity(Intent(requireContext(), AccountActivity::class.java))
        }
    }

}
