package id.ac.unp.ft.informatika.hydracheck.data.repository

import id.ac.unp.ft.informatika.hydracheck.data.local.HistoryDao
import id.ac.unp.ft.informatika.hydracheck.data.local.HistoryEntity
import kotlinx.coroutines.flow.Flow

class HistoryRepository(private val dao: HistoryDao) {

    // Ambil history milik user tertentu
    fun getHistory(uid: String): Flow<List<HistoryEntity>> {
        return dao.getHistory(uid)
    }

    // Insert 1 riwayat
    suspend fun insertHistory(
        userId: String,
        status: String,
        score: Int
    ) {
        val history = HistoryEntity(
            userId = userId,
            status = status,
            score = score
        )
        dao.insert(history)
    }

    // Hapus satu riwayat berdasarkan id
    suspend fun deleteHistory(id: Long) {
        dao.delete(id)
    }

    // Opsional: hapus seluruh riwayat user
    suspend fun deleteAllHistory(userId: String) {
        dao.deleteAll(userId)
    }
}
