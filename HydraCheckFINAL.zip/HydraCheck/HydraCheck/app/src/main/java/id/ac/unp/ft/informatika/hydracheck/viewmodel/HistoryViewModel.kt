package id.ac.unp.ft.informatika.hydracheck.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import id.ac.unp.ft.informatika.hydracheck.data.repository.HistoryRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HistoryViewModel(
    private val repo: HistoryRepository,
    private val userId: String
) : ViewModel() {

    // Flow dari Room → StateFlow untuk UI
    val history = repo.getHistory(userId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(), emptyList())

    // Insert riwayat baru
    fun insertHistory(status: String, score: Int) {
        viewModelScope.launch {
            repo.insertHistory(userId = userId, status = status, score = score)
        }
    }

    // Delete 1 item
    fun deleteHistory(id: Long) {
        viewModelScope.launch {
            repo.deleteHistory(id)
        }
    }

    // Delete semua riwayat user (opsional)
    fun clearAll() {
        viewModelScope.launch {
            repo.deleteAllHistory(userId)
        }
    }
}
