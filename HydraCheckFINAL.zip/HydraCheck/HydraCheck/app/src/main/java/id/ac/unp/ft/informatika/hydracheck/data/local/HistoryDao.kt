package id.ac.unp.ft.informatika.hydracheck.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {

    // Ambil semua riwayat berdasarkan userId (Firebase UID)
    @Query("SELECT * FROM history WHERE userId = :uid ORDER BY timestamp DESC")
    fun getHistory(uid: String): Flow<List<HistoryEntity>>

    // Insert data history
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(history: HistoryEntity)

    // Hapus 1 item riwayat berdasarkan id
    @Query("DELETE FROM history WHERE id = :id")
    suspend fun delete(id: Long)

    // Opsional: hapus semua history user tertentu
    @Query("DELETE FROM history WHERE userId = :uid")
    suspend fun deleteAll(uid: String)
}
