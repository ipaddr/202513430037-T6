package id.ac.unp.ft.informatika.hydracheck.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * HistoryEntity menyimpan hasil pemeriksaan hidrasi per user.
 *
 * Fields:
 * - id: primary key auto-generated (Long)
 * - userId: uid dari FirebaseAuth (String) -> untuk menyimpan riwayat per user
 * - timestamp: epoch millis saat rekaman dibuat (Long)
 * - score: nilai hasil tes (Int)
 * - status: teks status hidrasi (String)
 */
@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    val userId: String,              // uid Firebase, untuk relasi per user

    val timestamp: Long = System.currentTimeMillis(), // waktu pencatatan

    val score: Int,

    val status: String
)
