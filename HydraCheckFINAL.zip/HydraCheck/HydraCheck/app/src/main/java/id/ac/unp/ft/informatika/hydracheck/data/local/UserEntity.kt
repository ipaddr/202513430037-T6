package id.ac.unp.ft.informatika.hydracheck.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey
    val uid: String,      // UID Firebase
    val name: String,
    val email: String
)
