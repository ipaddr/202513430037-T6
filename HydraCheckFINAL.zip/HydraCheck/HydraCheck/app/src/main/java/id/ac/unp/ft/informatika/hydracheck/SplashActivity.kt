package id.ac.unp.ft.informatika.hydracheck

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // simple layout optional, or setContentView(R.layout.activity_splash)
        val user = FirebaseAuth.getInstance().currentUser
        if (user != null) {
            // sudah login -> main
            startActivity(Intent(this, MainActivity::class.java))
        } else {
            startActivity(Intent(this, id.ac.unp.ft.informatika.hydracheck.auth.LoginActivity::class.java))
        }
        finish()
    }
}
