package id.ac.unp.ft.informatika.hydracheck.fragmen

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import id.ac.unp.ft.informatika.hydracheck.HistoryAdapter
import id.ac.unp.ft.informatika.hydracheck.HistoryDetailActivity
import id.ac.unp.ft.informatika.hydracheck.R
import id.ac.unp.ft.informatika.hydracheck.data.model.HistoryItem

class HistoryFragment : Fragment(R.layout.fragment_history) {

    private lateinit var adapter: HistoryAdapter
    private val allItems = mutableListOf<HistoryItem>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvTitle = view.findViewById<TextView>(R.id.tvHistoryTitle)
        val rvHistory = view.findViewById<RecyclerView>(R.id.rvHistory)
        val progress = view.findViewById<ProgressBar>(R.id.progressHistory)
        val search = view.findViewById<SearchView>(R.id.searchHistory)

        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid == null) {
            tvTitle.text = "Harap login terlebih dahulu"
            return
        }

        tvTitle.text = "Riwayat Anda"

        // 🔥 INI BAGIAN PALING PENTING
        adapter = HistoryAdapter(
            items = emptyList(),
            onDetailClick = { item ->
                val intent = Intent(requireContext(), HistoryDetailActivity::class.java)
                intent.putExtra("SCORE", item.score)
                intent.putExtra("STATUS", item.status)
                intent.putExtra("DESC", item.description) // jika ada field ini
                startActivity(intent)
            },
            onDeleteClick = { id ->
                FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(uid)
                    .collection("history")
                    .document(id)
                    .delete()
                    .addOnSuccessListener {
                        loadHistory(uid)
                    }
            }
        )

        rvHistory.layoutManager = LinearLayoutManager(requireContext())
        rvHistory.adapter = adapter

        loadHistory(uid)

        search.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = false

            override fun onQueryTextChange(text: String?): Boolean {
                val keyword = text ?: ""

                search.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

                    override fun onQueryTextSubmit(query: String?) = false

                    override fun onQueryTextChange(text: String?): Boolean {
                        val keyword = text?.trim() ?: ""

                        if (keyword.isEmpty()) {
                            adapter.updateData(allItems)
                            return true
                        }

                        val filtered = allItems.filter { item ->
                            // 1️⃣ Cari berdasarkan STATUS
                            item.status.contains(keyword, ignoreCase = true)

                                    // 2️⃣ Cari berdasarkan SKOR
                                    || item.score.toString().contains(keyword)

                                    // 3️⃣ Cari berdasarkan TANGGAL
                                    || formatDate(item.timestamp)
                                .contains(keyword, ignoreCase = true)

                                    // 4️⃣ (Opsional) Deskripsi
                                    || (item.description?.contains(keyword, true) == true)
                        }

                        adapter.updateData(filtered)
                        return true
                    }
                })

                return true
            }
        })
    }

    private fun loadHistory(uid: String) {
        FirebaseFirestore.getInstance()
            .collection("users")
            .document(uid)
            .collection("history")
            .orderBy(
                "timestamp",
                com.google.firebase.firestore.Query.Direction.DESCENDING
            )
            .get()
            .addOnSuccessListener { snap ->

                allItems.clear()

                for (doc in snap.documents) {
                    val item = doc.toObject(HistoryItem::class.java)
                    if (item != null) {
                        item.id = doc.id
                        allItems.add(item)
                    }
                }

                adapter.updateData(allItems)
            }
    }

    private fun formatDate(time: Long): String {
        val sdf = java.text.SimpleDateFormat(
            "dd MMM yyyy",
            java.util.Locale.getDefault()
        )
        return sdf.format(java.util.Date(time))
    }

}
