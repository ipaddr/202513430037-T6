package id.ac.unp.ft.informatika.hydracheck

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import id.ac.unp.ft.informatika.hydracheck.fragmen.HomeFragment
import id.ac.unp.ft.informatika.hydracheck.fragmen.HistoryFragment
import id.ac.unp.ft.informatika.hydracheck.fragmen.InfoFragment
import android.content.Intent
import com.google.firebase.auth.FirebaseAuth
import id.ac.unp.ft.informatika.hydracheck.auth.LoginActivity


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Bottom Navigation Views
        val navHome = findViewById<View>(R.id.navHome)
        val navHistory = findViewById<View>(R.id.navHistory)
        val navInfo = findViewById<View>(R.id.navInfo)

        // Default fragment
        if (savedInstanceState == null) {
            openFragment(HomeFragment())
            setActiveNav(R.id.navHome)
        }

        navHome.setOnClickListener {
            openFragment(HomeFragment())
            setActiveNav(R.id.navHome)
        }

        navHistory.setOnClickListener {
            openFragment(HistoryFragment())
            setActiveNav(R.id.navHistory)
        }

        navInfo.setOnClickListener {
            openFragment(InfoFragment())
            setActiveNav(R.id.navInfo)
        }
    }

    fun openHistoryFromHome() {
        openFragment(HistoryFragment())
        setActiveNav(R.id.navHistory)
    }


    fun openFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(
                R.anim.fragment_enter,
                R.anim.fragment_exit,
                R.anim.fragment_enter,
                R.anim.fragment_exit
            )
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    fun setActiveNav(activeId: Int) {
        val activeColor = ContextCompat.getColor(this, R.color.nav_active)
        val inactiveColor = ContextCompat.getColor(this, R.color.text_gray)

        findViewById<View>(R.id.navHome).isSelected = activeId == R.id.navHome
        findViewById<View>(R.id.navHistory).isSelected = activeId == R.id.navHistory
        findViewById<View>(R.id.navInfo).isSelected = activeId == R.id.navInfo
    }

    override fun onStart() {
        super.onStart()

        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }


}
