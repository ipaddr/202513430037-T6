package id.ac.unp.ft.informatika.hydracheck.auth

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import id.ac.unp.ft.informatika.hydracheck.R
import id.ac.unp.ft.informatika.hydracheck.data.local.AppDatabase
import id.ac.unp.ft.informatika.hydracheck.data.repository.UserRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class RegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private lateinit var userRepo: UserRepository


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // === Firebase ===
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // === Room (lokal, opsional tapi kamu pakai) ===
        val db = AppDatabase.getInstance(this)
        userRepo = UserRepository(db.userDao())

        // === View ===
        val etName = findViewById<EditText>(R.id.etName)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnRegister = findViewById<Button>(R.id.btnRegister)

        btnRegister.setOnClickListener {
            val name = etName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Semua field wajib diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            registerUser(name, email, password)
        }
    }

    private fun registerUser(name: String, email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                val user = result.user ?: return@addOnSuccessListener

                // 1️⃣ Update displayName di FirebaseAuth
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(name)
                    .build()

                user.updateProfile(profileUpdates)

                // 2️⃣ Simpan ke Firestore (WAJIB)
                val userData = hashMapOf(
                    "uid" to user.uid,
                    "name" to name,
                    "email" to email,
                    "photoBase64" to "" // foto akan kita isi nanti
                )

                firestore.collection("users")
                    .document(user.uid)
                    .set(userData)
                    .addOnSuccessListener {

                        // 3️⃣ Simpan ke Room (lokal)
                        CoroutineScope(Dispatchers.IO).launch {
                            userRepo.saveUser(
                                uid = user.uid,
                                name = name,
                                email = email
                            )
                        }

                        Toast.makeText(
                            this,
                            "Registrasi berhasil, silakan login",
                            Toast.LENGTH_SHORT
                        ).show()

                        finish()
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(
                            this,
                            "Gagal simpan data user: ${e.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
            }
            .addOnFailureListener { e ->
                Toast.makeText(
                    this,
                    "Registrasi gagal: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }
}
