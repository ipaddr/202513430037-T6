package id.ac.unp.ft.informatika.hydracheck

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class HistoryDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history_detail)

        // ================= VIEW =================
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val tvStatus = findViewById<TextView>(R.id.tvDetailStatus)
        val tvScore = findViewById<TextView>(R.id.tvDetailScore)
        val tvDate = findViewById<TextView>(R.id.tvDetailDate)
        val tvDesc = findViewById<TextView>(R.id.tvDetailDesc)

        // ================= DATA DARI INTENT =================
        val score = intent.getIntExtra("SCORE", 0)
        val status = intent.getStringExtra("STATUS") ?: "-"
        val timestamp = intent.getLongExtra("TIMESTAMP", 0L)

        // ================= SET UI =================
        tvStatus.text = status
        when (status) {
            "Hidrasi Baik" -> {
                tvStatus.setTextColor(getColor(R.color.status_good))
                tvStatus.setBackgroundResource(R.drawable.bg_status_good)
            }

            "Dehidrasi Ringan" -> {
                tvStatus.setTextColor(getColor(R.color.status_light))
                tvStatus.setBackgroundResource(R.drawable.bg_status_light)
            }

            "Dehidrasi Sedang" -> {
                tvStatus.setTextColor(getColor(R.color.status_medium))
                tvStatus.setBackgroundResource(R.drawable.bg_status_medium)
            }

            else -> {
                tvStatus.setTextColor(getColor(R.color.status_bad))
                tvStatus.setBackgroundResource(R.drawable.bg_status_bad)
            }
        }

        tvStatus.setTextColor(
            when (status) {
                "Hidrasi Baik" -> getColor(R.color.status_good)
                "Dehidrasi Ringan" -> getColor(R.color.status_light)
                "Dehidrasi Sedang" -> getColor(R.color.status_medium)
                else -> getColor(R.color.status_bad)
            }
        )

        tvScore.text = "Skor: $score"
        tvDate.text = formatDate(timestamp)
        tvDesc.text = getDescriptionByStatus(status)

        // ================= BACK =================
        btnBack.setOnClickListener {
            finish()
        }
    }

    private fun getDescriptionByStatus(status: String): String {
        return when (status) {

            "Hidrasi Baik" ->
                "Kondisi hidrasi tubuh Anda sangat baik. Asupan cairan sudah mencukupi, pertahankan kebiasaan minum air secara teratur."

            "Dehidrasi Ringan" ->
                "Tubuh mulai menunjukkan tanda kekurangan cairan. Disarankan untuk lebih sering minum air dan memperhatikan kebutuhan cairan harian."

            "Dehidrasi Sedang" ->
                "Tubuh Anda mengalami kekurangan cairan yang cukup signifikan. Tingkatkan konsumsi air putih dan kurangi aktivitas berat."

            "Dehidrasi Berat" ->
                "Tubuh mengalami kekurangan cairan yang serius. Segera tingkatkan asupan cairan, istirahat cukup, dan waspadai gejala seperti pusing atau lemas."

            else -> "-"
        }
    }

    // ================= FORMAT TANGGAL =================
    private fun formatDate(time: Long): String {
        if (time == 0L) return "-"
        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
        return sdf.format(Date(time))
    }
}
