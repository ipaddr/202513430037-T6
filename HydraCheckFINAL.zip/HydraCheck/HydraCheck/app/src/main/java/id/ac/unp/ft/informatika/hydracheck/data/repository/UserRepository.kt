package id.ac.unp.ft.informatika.hydracheck.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.GoogleAuthProvider
import id.ac.unp.ft.informatika.hydracheck.data.local.UserDao
import id.ac.unp.ft.informatika.hydracheck.data.local.UserEntity
import kotlinx.coroutines.tasks.await

class UserRepository(private val userDao: UserDao) {

    private val auth = FirebaseAuth.getInstance()

    // LOGIN EMAIL
    suspend fun loginWithEmail(email: String, password: String): AuthResult {
        return auth.signInWithEmailAndPassword(email, password).await()
    }

    // LOGIN GOOGLE
    suspend fun loginWithGoogle(idToken: String): AuthResult {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        return auth.signInWithCredential(credential).await()
    }

    // SIMPAN USER DARI FIREBASE KE ROOM
    suspend fun saveUser(uid: String, name: String, email: String) {
        val user = UserEntity(
            uid = uid,
            name = name,
            email = email
        )
        userDao.insert(user)
    }

    // AMBIL USER DARI ROOM
    suspend fun getLoggedInUser(uid: String): UserEntity? {
        return userDao.getUserById(uid)
    }

    // LOGOUT
    fun logout() = auth.signOut()
}
