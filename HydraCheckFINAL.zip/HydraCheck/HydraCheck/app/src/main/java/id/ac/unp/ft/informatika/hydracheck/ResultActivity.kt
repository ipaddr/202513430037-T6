package id.ac.unp.ft.informatika.hydracheck

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        // ================= VIEW =================
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val btnDone = findViewById<Button>(R.id.btnDone)
        val btnHistory = findViewById<Button>(R.id.btnHistory)

        val tvScore = findViewById<TextView>(R.id.tvScore)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        val tvDescription = findViewById<TextView>(R.id.tvDescription)
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)

        // ================= DATA DARI QUESTION =================
        val totalScore = intent.getIntExtra("TOTAL_SCORE", 0)
        val status = intent.getStringExtra("STATUS") ?: "-"
        val answers = intent.getIntArrayExtra("ANSWERS") ?: intArrayOf()

        val maxScore = answers.size * 3
        val percent = if (maxScore == 0) 0 else (totalScore * 100 / maxScore)

        // ================= DESKRIPSI BERDASARKAN STATUS =================
        val description = when (status) {
            "Tidak Hidrasi" ->
                "Tubuh Anda kekurangan cairan. Segera tingkatkan konsumsi air."
            "Hidrasi Ringan" ->
                "Asupan cairan masih kurang. Minum air secara rutin."
            "Hidrasi Sedang" ->
                "Kondisi hidrasi cukup baik, tetap jaga pola minum."
            else ->
                "Tubuh Anda terhidrasi dengan baik. Pertahankan kebiasaan ini."
        }

        // ================= TAMPILKAN =================
        tvScore.text = "$totalScore / $maxScore"
        tvStatus.text = status
        when (status) {

            "Hidrasi Baik" -> {
                tvStatus.setTextColor(getColor(R.color.status_good))
                tvStatus.setBackgroundResource(R.drawable.bg_status_good)
            }

            "Dehidrasi Ringan" -> {
                tvStatus.setTextColor(getColor(R.color.status_light))
                tvStatus.setBackgroundResource(R.drawable.bg_status_light)
            }

            "Dehidrasi Sedang" -> {
                tvStatus.setTextColor(getColor(R.color.status_medium))
                tvStatus.setBackgroundResource(R.drawable.bg_status_medium)
            }

            else -> {
                tvStatus.setTextColor(getColor(R.color.status_bad))
                tvStatus.setBackgroundResource(R.drawable.bg_status_bad)
            }
        }

        tvStatus.setTextColor(
            when (status) {
                "Hidrasi Baik" -> getColor(R.color.status_good)
                "Dehidrasi Ringan" -> getColor(R.color.status_light)
                "Dehidrasi Sedang" -> getColor(R.color.status_medium)
                else -> getColor(R.color.status_bad)
            }
        )

        tvDescription.text = description
        progressBar.progress = percent
        when (status) {
            "Hidrasi Baik" -> {
                progressBar.progressDrawable.setTint(getColor(R.color.status_good))
            }

            "Dehidrasi Ringan" -> {
                progressBar.progressDrawable.setTint(getColor(R.color.status_light))
            }

            "Dehidrasi Sedang" -> {
                progressBar.progressDrawable.setTint(getColor(R.color.status_medium))
            }

            else -> {
                progressBar.progressDrawable.setTint(getColor(R.color.status_bad))
            }
        }


        // ================= SIMPAN KE FIRESTORE =================
        saveResultToFirestore(
            score = totalScore,
            status = status,
            answers = answers.toList()
        )

        // ================= ACTION =================
        btnBack.setOnClickListener { finish() }

        btnDone.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish()
        }

        btnHistory.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("OPEN_HISTORY", true)
            startActivity(intent)
            finish()
        }
    }

    // ================= SIMPAN FIRESTORE =================
    private fun saveResultToFirestore(
        score: Int,
        status: String,
        answers: List<Int>
    ) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return

        val data = hashMapOf(
            "score" to score,
            "status" to status,
            "timestamp" to System.currentTimeMillis(),
            "answers" to answers
        )

        FirebaseFirestore.getInstance()
            .collection("users")
            .document(uid)
            .collection("history")
            .add(data)
    }
}
