package id.ac.unp.ft.informatika.hydracheck

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import id.ac.unp.ft.informatika.hydracheck.data.model.HistoryItem
import java.text.SimpleDateFormat
import java.util.*

class HistoryAdapter(
    private var items: List<HistoryItem>,
    private val onDetailClick: (HistoryItem) -> Unit,
    private val onDeleteClick: (String) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    inner class HistoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvDate: TextView = view.findViewById(R.id.tvHistoryDate)
        val tvScore: TextView = view.findViewById(R.id.tvHistoryScore)
        val tvStatus: TextView = view.findViewById(R.id.tvHistoryStatus)
        val tvDetail: TextView = view.findViewById(R.id.tvDetail)
        val tvDelete: TextView = view.findViewById(R.id.tvDelete)
        val indicator: View = view.findViewById(R.id.viewIndicator)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_history, parent, false)
        return HistoryViewHolder(view)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val item = items[position]

        holder.tvDate.text = formatDate(item.timestamp)
        holder.tvScore.text = "Skor: ${item.score}"
        holder.tvStatus.text = item.status

        when (item.status) {
            "Hidrasi Baik" -> {
                holder.tvStatus.setTextColor(
                    holder.itemView.context.getColor(R.color.status_good)
                )
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_good)
            }

            "Dehidrasi Ringan" -> {
                holder.tvStatus.setTextColor(
                    holder.itemView.context.getColor(R.color.status_light)
                )
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_light)
            }

            "Dehidrasi Sedang" -> {
                holder.tvStatus.setTextColor(
                    holder.itemView.context.getColor(R.color.status_medium)
                )
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_medium)
            }

            else -> {
                holder.tvStatus.setTextColor(
                    holder.itemView.context.getColor(R.color.status_bad)
                )
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_bad)
            }
        }
        when (item.status) {

            "Hidrasi Baik" -> {
                holder.indicator.setBackgroundColor(
                    holder.itemView.context.getColor(R.color.status_good)
                )
            }

            "Dehidrasi Ringan" -> {
                holder.indicator.setBackgroundColor(
                    holder.itemView.context.getColor(R.color.status_light)
                )
            }

            "Dehidrasi Sedang" -> {
                holder.indicator.setBackgroundColor(
                    holder.itemView.context.getColor(R.color.status_medium)
                )
            }

            else -> {
                holder.indicator.setBackgroundColor(
                    holder.itemView.context.getColor(R.color.status_bad)
                )
            }
        }


        holder.tvStatus.setTextColor(
            when (item.status) {
                "Hidrasi Baik" ->
                    holder.itemView.context.getColor(R.color.status_good)

                "Dehidrasi Ringan" ->
                    holder.itemView.context.getColor(R.color.status_light)

                "Dehidrasi Sedang" ->
                    holder.itemView.context.getColor(R.color.status_medium)

                else ->
                    holder.itemView.context.getColor(R.color.status_bad)
            }
        )


        holder.tvDetail.setOnClickListener { onDetailClick(item) }
        holder.tvDelete.setOnClickListener { onDeleteClick(item.id) }
    }

    fun updateData(newItems: List<HistoryItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    private fun formatDate(time: Long): String {
        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
        return sdf.format(Date(time))
    }
}
