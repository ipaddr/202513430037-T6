package id.ac.unp.ft.informatika.hydracheck.fragmen

import androidx.fragment.app.Fragment
import id.ac.unp.ft.informatika.hydracheck.R

class InfoFragment : Fragment(R.layout.fragment_info)
